<template>
	<n-button>naive ui</n-button>
	<h2>我是home页</h2>
</template>

<script>
	export default {
	  name: 'Home',
	}
</script>

<style>
</style>