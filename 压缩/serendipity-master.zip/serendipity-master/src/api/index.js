import requests from './request'

export const reqCategoryList = () =>{
	return requests({
		url:'',
		method:''
	})
}